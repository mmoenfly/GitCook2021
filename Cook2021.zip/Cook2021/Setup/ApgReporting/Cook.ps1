get-host | Select-Object version
get-location