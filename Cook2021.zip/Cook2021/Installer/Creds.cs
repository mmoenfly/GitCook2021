﻿using System;
namespace Installer
{
	public class Creds
	{
		 
		
	    public string server { get; set; }
		public user userid { get; set; }
		public user pwd { get; set; }

	}
	
}