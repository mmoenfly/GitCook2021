﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: Guid("ca0afc7f-c321-4fc6-98d5-115b24a14d70")]
[assembly: AssemblyTitle("Partial")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("Partial")]
[assembly: AssemblyCopyright("Copyright ©  2012")]
[assembly: AssemblyTrademark("")]
[assembly: ComVisible(false)]
[assembly: AssemblyVersion("4.0.0.0")]
