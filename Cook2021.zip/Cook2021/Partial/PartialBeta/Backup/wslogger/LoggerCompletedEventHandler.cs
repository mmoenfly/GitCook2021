﻿// Decompiled with JetBrains decompiler
// Type: Partial.wslogger.LoggerCompletedEventHandler
// Assembly: PartialBeta, Version=4.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 9CF783A5-38FA-472F-8C51-9A2203433095
// Assembly location: E:\git\partialbits\PartialBeta.exe

using System.CodeDom.Compiler;

namespace Partial.wslogger
{
  [GeneratedCode("System.Web.Services", "2.0.50727.5420")]
  public delegate void LoggerCompletedEventHandler(object sender, LoggerCompletedEventArgs e);
}
